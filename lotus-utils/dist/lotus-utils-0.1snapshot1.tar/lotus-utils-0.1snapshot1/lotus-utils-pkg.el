(define-package "lotus-utils" "0.1snapshot1" "copy config"
  '((emacs "24.3")))
;; Local Variables:
;; no-byte-compile: t
;; End:
